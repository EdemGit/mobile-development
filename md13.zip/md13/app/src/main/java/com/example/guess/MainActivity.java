package com.example.guess;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

public class MainActivity extends AppCompatActivity {
    TextView tvInfo;
    EditText etInput;
    Button bControl;
    Integer num;
    Boolean game;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tvInfo = (TextView)findViewById(R.id.textView);
        etInput = (EditText)findViewById(R.id.editTextNumber);
        bControl = (Button)findViewById(R.id.button);
        num = ThreadLocalRandom.current().nextInt(1, 101);
        game = true;
    }
    public void onClick(View v) {
        if (!game) {
            Random random = new Random();
            num = random.nextInt(100) + 1;
            game = true;
            tvInfo.setText(R.string.try_to_guess);
            bControl.setText(R.string.input_value);
            return;
        }
        int in = Integer.parseInt(etInput.getText().toString());
        if (in < num) {
            tvInfo.setText(R.string.behind);
        } else if (in > num) {
            tvInfo.setText(R.string.ahead);
        } else {
            tvInfo.setText(R.string.hit);
            bControl.setText(R.string.play_more);
            game = false;
        }
    }
}
